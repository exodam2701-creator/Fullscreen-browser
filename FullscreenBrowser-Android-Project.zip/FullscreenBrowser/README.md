# Fullscreen Browser (Android)

Aplikasi browser Android sederhana berbasis WebView.

## Fitur
- Membuka berbagai website dan pencarian Google dari kolom alamat.
- Mode immersive fullscreen: status bar dan navigation bar disembunyikan.
- Tombol kembali, maju, refresh, dan kolom alamat.
- JavaScript dan penyimpanan DOM diaktifkan agar banyak situs modern dapat berjalan.

## Membuat APK
1. Instal Android Studio versi terbaru di komputer.
2. Buka folder `FullscreenBrowser` melalui **Open**.
3. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh Android SDK Platform 35 jika diminta.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Proyek ini adalah browser WebView dasar, bukan browser dengan mesin Chromium mandiri.
- Beberapa situs mungkin membatasi WebView atau meminta fitur tambahan seperti upload file, unduhan, kamera, atau pop-up.
- Fullscreen immersive dapat menampilkan kembali system bar sementara saat pengguna menggeser dari tepi layar; Android mengontrol perilaku sistem ini.
- `usesCleartextTraffic=true` dipakai agar situs HTTP lama tetap bisa dibuka. Utamakan HTTPS untuk keamanan.
